#pragma once

class ClassPreset
{
public:
	//	Other


	//	Rule of 5
	~ClassPreset() = default;

	ClassPreset(const ClassPreset& other) = default;
	ClassPreset(ClassPreset&& other) = default;
	ClassPreset& operator=(const ClassPreset& other) = default;
	ClassPreset& operator=(ClassPreset&& other) = default;

	//	Other special methods
	ClassPreset() = default;

	//	Methods
	

	//	Setters
	

	//	Getters


protected:


private:

};